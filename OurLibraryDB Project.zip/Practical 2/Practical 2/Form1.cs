﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practical_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void viewAllBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmViewBooks viewForm = new FrmViewBooks();
            viewForm.MdiParent = this;
            viewForm.Show();
        }

        private void searchBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmSearchBooks searchForm = new FrmSearchBooks();
            searchForm.MdiParent = this;
            searchForm.Show();
        }
    }
}
