﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Practical_2
{
    public partial class FrmViewBooks : Form
    {
        SqlConnection conn;
        SqlDataAdapter adap = new SqlDataAdapter();
        DataSet ds = new DataSet();
        public FrmViewBooks()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            // Connect to the database
            string conStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\OurLibraryDB.mdf;Integrated Security=True";
            conn = new SqlConnection(conStr);

            MessageBox.Show("Connection Successful");
        }

        private void btnShowBooks_Click(object sender, EventArgs e)
        {
            // Open Connection
            conn.Open();

            // Create the query and pass to command
            string sql = "SELECT * FROM Books";
            SqlCommand comm = new SqlCommand(sql, conn);

            // Fill the dataset
            adap.SelectCommand = comm;
            adap.Fill(ds, "Books");

            // Display the data on the data grid view
            dgvViewBooks.DataSource = ds;
            dgvViewBooks.DataMember = "Books";

            // Close connection
            conn.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            try
            {
                // Open Connection
                conn.Open();

                // Create the query and pass to command
                string sql = "SELECT * FROM Books WHERE Genre = '" + cmbSearchBooks.Text + "'";
                SqlCommand comm = new SqlCommand(sql, conn);
                

                // Fill the dataset
                adap.SelectCommand = comm;
                adap.Fill(ds, "Books");

                // Display the data on the data grid view
                dgvViewBooks.DataSource = ds;
                dgvViewBooks.DataMember = "Books";

                // Close connection
                conn.Close();
            }
            catch(SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }

        
    }
}
