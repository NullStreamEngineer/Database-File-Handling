﻿
namespace Practical_2
{
    partial class FrmViewBooks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnShowBooks = new System.Windows.Forms.Button();
            this.cmbSearchBooks = new System.Windows.Forms.ComboBox();
            this.dgvViewBooks = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewBooks)).BeginInit();
            this.SuspendLayout();
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(885, 65);
            this.btnConnect.Margin = new System.Windows.Forms.Padding(4);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(212, 47);
            this.btnConnect.TabIndex = 0;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnShowBooks
            // 
            this.btnShowBooks.Location = new System.Drawing.Point(885, 171);
            this.btnShowBooks.Margin = new System.Windows.Forms.Padding(4);
            this.btnShowBooks.Name = "btnShowBooks";
            this.btnShowBooks.Size = new System.Drawing.Size(212, 47);
            this.btnShowBooks.TabIndex = 1;
            this.btnShowBooks.Text = "Show Books";
            this.btnShowBooks.UseVisualStyleBackColor = true;
            this.btnShowBooks.Click += new System.EventHandler(this.btnShowBooks_Click);
            // 
            // cmbSearchBooks
            // 
            this.cmbSearchBooks.FormattingEnabled = true;
            this.cmbSearchBooks.Items.AddRange(new object[] {
            "Fiction",
            "Programming",
            "Classic",
            "Literature"});
            this.cmbSearchBooks.Location = new System.Drawing.Point(885, 263);
            this.cmbSearchBooks.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSearchBooks.Name = "cmbSearchBooks";
            this.cmbSearchBooks.Size = new System.Drawing.Size(200, 24);
            this.cmbSearchBooks.TabIndex = 2;
            this.cmbSearchBooks.Text = "Select Genre to search";
            this.cmbSearchBooks.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dgvViewBooks
            // 
            this.dgvViewBooks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvViewBooks.Location = new System.Drawing.Point(29, 15);
            this.dgvViewBooks.Margin = new System.Windows.Forms.Padding(4);
            this.dgvViewBooks.Name = "dgvViewBooks";
            this.dgvViewBooks.RowHeadersWidth = 51;
            this.dgvViewBooks.Size = new System.Drawing.Size(789, 351);
            this.dgvViewBooks.TabIndex = 3;
            // 
            // FrmViewBooks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1204, 498);
            this.Controls.Add(this.dgvViewBooks);
            this.Controls.Add(this.cmbSearchBooks);
            this.Controls.Add(this.btnShowBooks);
            this.Controls.Add(this.btnConnect);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmViewBooks";
            this.Text = "View All Books";
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewBooks)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnShowBooks;
        private System.Windows.Forms.ComboBox cmbSearchBooks;
        private System.Windows.Forms.DataGridView dgvViewBooks;
    }
}