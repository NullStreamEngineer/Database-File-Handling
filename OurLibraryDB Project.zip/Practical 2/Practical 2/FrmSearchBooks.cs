﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Practical_2
{
    
    public partial class FrmSearchBooks : Form
    {
        SqlConnection conn;
        public FrmSearchBooks()
        {
            InitializeComponent();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            
            string search = txtSearch.Text;
            try
            {
                // Declare adapter and dataset
                SqlDataAdapter adap = new SqlDataAdapter();
                DataSet ds = new DataSet();

                // Open Connection
                conn.Open();

                // Create the query and pass to command
                string sql = @"SELECT * FROM Books WHERE Author LIKE '%" + search + "%'";
                SqlCommand comm = new SqlCommand(sql, conn);

                // Fill the dataset
                adap.SelectCommand = comm;
                adap.Fill(ds, "Books");

                dgvViewBooks.DataSource = ds;
                dgvViewBooks.DataMember = "Books";

                // Close connection
                conn.Close();
            }
            catch(SqlException err)
            {
                MessageBox.Show(err.Message);
            }


        }

        

        private void hScrollBar1_Scroll_1(object sender, ScrollEventArgs e)
        {
            // Update the year displayed on form
            lblYear.Text = hScrollBar1.Value.ToString();

            try
            {
                //Select * records from books where the year is equal to the ScrollBar's current value
                string sql = "SELECT * FROM Books WHERE YearPublished = '" + hScrollBar1.Value + "'";

                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);

                // Open Connection
                conn.Open();

                DataSet ds = new DataSet();
                adapter.Fill(ds, "Books");

                dgvViewBooks.DataSource = ds;
                dgvViewBooks.DataMember = "Books";
                conn.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void FrmSearchBooks_Load(object sender, EventArgs e)
        {
            string conStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\OurLibraryDB.mdf;Integrated Security=True";
            conn = new SqlConnection(conStr);
        }
    }
}
