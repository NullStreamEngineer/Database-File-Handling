﻿CREATE TABLE [dbo].[Books]
(
	[BookID] INT NOT NULL PRIMARY KEY, 
    [Title] NVARCHAR(50) NULL, 
    [Author] NVARCHAR(50) NULL, 
    [Genre] NVARCHAR(50) NULL, 
    [YearPublished] INT NULL
)
