﻿CREATE TABLE [dbo].[Equipment]
(
	[EquipmentID] INT NOT NULL PRIMARY KEY, 
    [EquipmentName] NVARCHAR(50) NULL, 
    [Category] NCHAR(10) NULL, 
    [Status] NVARCHAR(50) NOT NULL
)
