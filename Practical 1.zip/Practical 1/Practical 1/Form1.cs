﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practical_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void equipmentDisplayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmDisplayEquipment display = new FrmDisplayEquipment();
            display.MdiParent = this;
            display.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void equipmentAvailabilityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmEquipentAvailability displayAvailable = new FrmEquipentAvailability();
            displayAvailable.MdiParent = this;
            displayAvailable.Show();
        }
    }
}
