﻿
namespace Practical_1
{
    partial class FrmDisplayEquipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblSearch = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.dgvEquipmentDisplay = new System.Windows.Forms.DataGridView();
            this.btnDisplayEquipment = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEquipmentDisplay)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(778, 53);
            this.lblSearch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(396, 20);
            this.lblSearch.TabIndex = 9;
            this.lblSearch.Text = "Type below to search for equipment you need:";
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(782, 92);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(241, 26);
            this.txtSearch.TabIndex = 8;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // dgvEquipmentDisplay
            // 
            this.dgvEquipmentDisplay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEquipmentDisplay.Location = new System.Drawing.Point(17, 53);
            this.dgvEquipmentDisplay.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvEquipmentDisplay.Name = "dgvEquipmentDisplay";
            this.dgvEquipmentDisplay.RowHeadersWidth = 51;
            this.dgvEquipmentDisplay.Size = new System.Drawing.Size(718, 315);
            this.dgvEquipmentDisplay.TabIndex = 7;
            // 
            // btnDisplayEquipment
            // 
            this.btnDisplayEquipment.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplayEquipment.Location = new System.Drawing.Point(365, 444);
            this.btnDisplayEquipment.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDisplayEquipment.Name = "btnDisplayEquipment";
            this.btnDisplayEquipment.Size = new System.Drawing.Size(132, 57);
            this.btnDisplayEquipment.TabIndex = 6;
            this.btnDisplayEquipment.Text = "Display Equipment";
            this.toolTip1.SetToolTip(this.btnDisplayEquipment, "Click here to display Table Data");
            this.btnDisplayEquipment.UseVisualStyleBackColor = true;
            this.btnDisplayEquipment.Click += new System.EventHandler(this.btnDisplayEquipment_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnect.Location = new System.Drawing.Point(36, 444);
            this.btnConnect.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(132, 57);
            this.btnConnect.TabIndex = 5;
            this.btnConnect.Text = "Connect";
            this.toolTip1.SetToolTip(this.btnConnect, "Click here to connect to the DB");
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // FrmDisplayEquipment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1252, 554);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.dgvEquipmentDisplay);
            this.Controls.Add(this.btnDisplayEquipment);
            this.Controls.Add(this.btnConnect);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmDisplayEquipment";
            this.Text = "DisplayEquipment";
            ((System.ComponentModel.ISupportInitialize)(this.dgvEquipmentDisplay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.DataGridView dgvEquipmentDisplay;
        private System.Windows.Forms.Button btnDisplayEquipment;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}