﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Practical_1
{
    public partial class FrmEquipentAvailability : Form
    {
        SqlConnection conn;
        SqlDataReader reader;
        public FrmEquipentAvailability()
        {
            InitializeComponent();
        }

        private void cmbSelection_SelectedIndexChanged(object sender, EventArgs e)
        {
            string conStr = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = |DataDirectory|\CSIS.mdf; Integrated Security = True";
            conn = new SqlConnection(conStr);
            string selection = cmbSelection.Text;

            string sql, output = "";
            conn.Open();

            try
            {
                

                sql = "SELECT * FROM Equipment WHERE Status = '"+selection+"'";
                SqlCommand comm = new SqlCommand(sql, conn);
                reader = comm.ExecuteReader();

                lstDisplayEquipment.Items.Add("EquipmentID||EquipmentName||Category||Availability");
                lstDisplayEquipment.Items.Add("===============================================================");

                while (reader.Read())
                {
                    output = reader.GetValue(0) + "\t" + reader.GetValue(1) + "\t" + reader.GetValue(2) + "\t" + reader.GetValue(3) + "\n";
                    lstDisplayEquipment.Items.Add(output);

                }
                conn.Close();
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstDisplayEquipment.Items.Clear();
        }
    }
}
