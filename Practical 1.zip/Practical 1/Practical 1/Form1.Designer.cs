﻿
namespace Practical_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.equipmentDisplayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equipmentAvailabilityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.equipmentDisplayToolStripMenuItem,
            this.equipmentAvailabilityToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(885, 25);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // equipmentDisplayToolStripMenuItem
            // 
            this.equipmentDisplayToolStripMenuItem.Name = "equipmentDisplayToolStripMenuItem";
            this.equipmentDisplayToolStripMenuItem.Size = new System.Drawing.Size(128, 21);
            this.equipmentDisplayToolStripMenuItem.Text = "Equipment Display";
            this.equipmentDisplayToolStripMenuItem.Click += new System.EventHandler(this.equipmentDisplayToolStripMenuItem_Click);
            // 
            // equipmentAvailabilityToolStripMenuItem
            // 
            this.equipmentAvailabilityToolStripMenuItem.Name = "equipmentAvailabilityToolStripMenuItem";
            this.equipmentAvailabilityToolStripMenuItem.Size = new System.Drawing.Size(147, 21);
            this.equipmentAvailabilityToolStripMenuItem.Text = "Equipment Availability";
            this.equipmentAvailabilityToolStripMenuItem.Click += new System.EventHandler(this.equipmentAvailabilityToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(885, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "CSIS Tech Room";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem equipmentDisplayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equipmentAvailabilityToolStripMenuItem;
    }
}

