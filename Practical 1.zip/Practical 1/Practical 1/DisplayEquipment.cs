﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Practical_1
{
    public partial class FrmDisplayEquipment : Form
    {
        SqlConnection conn;
        

        public FrmDisplayEquipment()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            string conStr = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = |DataDirectory|\CSIS.mdf; Integrated Security = True";
            conn = new SqlConnection(conStr);
            MessageBox.Show("Connected Successfully");
        }

        private void btnDisplayEquipment_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = @"SELECT * FROM Equipment";

                

                SqlCommand comm = new SqlCommand(sql, conn);
                SqlDataAdapter adap = new SqlDataAdapter();
                DataSet ds = new DataSet();
                adap.SelectCommand = comm;

                adap.Fill(ds, "Equipment");

                dgvEquipmentDisplay.DataSource = ds;
                dgvEquipmentDisplay.DataMember = "Equipment";

                conn.Close();

            }
            catch(SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string search = txtSearch.Text;
            try
            {
                conn.Open();

                string sql = @"SELECT * FROM Equipment WHERE EquipmentName LIKE '%"+search+"%'";

                SqlCommand comm = new SqlCommand(sql, conn);
                SqlDataAdapter adap = new SqlDataAdapter();
                DataSet ds = new DataSet();

                adap.SelectCommand = comm;
                adap.Fill(ds, "Equipment");

                dgvEquipmentDisplay.DataSource = ds;
                dgvEquipmentDisplay.DataMember = "Equipment";

                conn.Close();

            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }
    }
}
