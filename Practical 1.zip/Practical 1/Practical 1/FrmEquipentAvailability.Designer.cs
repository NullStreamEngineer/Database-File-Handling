﻿
namespace Practical_1
{
    partial class FrmEquipentAvailability
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSelection = new System.Windows.Forms.Label();
            this.cmbSelection = new System.Windows.Forms.ComboBox();
            this.lstDisplayEquipment = new System.Windows.Forms.ListBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblSelection
            // 
            this.lblSelection.AutoSize = true;
            this.lblSelection.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelection.Location = new System.Drawing.Point(17, 33);
            this.lblSelection.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelection.Name = "lblSelection";
            this.lblSelection.Size = new System.Drawing.Size(485, 20);
            this.lblSelection.TabIndex = 0;
            this.lblSelection.Text = "Select status to see available and borrowed equipments:";
            // 
            // cmbSelection
            // 
            this.cmbSelection.FormattingEnabled = true;
            this.cmbSelection.Items.AddRange(new object[] {
            "Available",
            "Borrowed"});
            this.cmbSelection.Location = new System.Drawing.Point(84, 84);
            this.cmbSelection.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbSelection.Name = "cmbSelection";
            this.cmbSelection.Size = new System.Drawing.Size(243, 24);
            this.cmbSelection.TabIndex = 1;
            this.cmbSelection.Text = "Select Status";
            this.cmbSelection.SelectedIndexChanged += new System.EventHandler(this.cmbSelection_SelectedIndexChanged);
            // 
            // lstDisplayEquipment
            // 
            this.lstDisplayEquipment.FormattingEnabled = true;
            this.lstDisplayEquipment.ItemHeight = 16;
            this.lstDisplayEquipment.Location = new System.Drawing.Point(589, 33);
            this.lstDisplayEquipment.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lstDisplayEquipment.Name = "lstDisplayEquipment";
            this.lstDisplayEquipment.Size = new System.Drawing.Size(561, 244);
            this.lstDisplayEquipment.TabIndex = 2;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(84, 140);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 28);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // FrmEquipentAvailability
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1271, 425);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lstDisplayEquipment);
            this.Controls.Add(this.cmbSelection);
            this.Controls.Add(this.lblSelection);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmEquipentAvailability";
            this.Text = "FrmEquipentAvailability";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSelection;
        private System.Windows.Forms.ComboBox cmbSelection;
        private System.Windows.Forms.ListBox lstDisplayEquipment;
        private System.Windows.Forms.Button btnClear;
    }
}